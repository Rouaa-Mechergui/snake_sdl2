#include "graphics.h"

// Initialisation de SDL2 et cr�ation de la fen�tre
bool initGraphics(Graphics *gfx) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur SDL: %s\n", SDL_GetError());
        return false;
    }

    gfx->window = SDL_CreateWindow("Snake Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                   Largeur_Map * CELL_SIZE, MAP_HEIGHT * CELL_SIZE, SDL_WINDOW_SHOWN);
    if (!gfx->window) {
        printf("Erreur cr�ation fen�tre: %s\n", SDL_GetError());
        return false;
    }

    gfx->renderer = SDL_CreateRenderer(gfx->window, -1, SDL_RENDERER_ACCELERATED);
    if (!gfx->renderer) {
        printf("Erreur cr�ation renderer: %s\n", SDL_GetError());
        return false;
    }

    return true;
}

// Nettoyage des ressources SDL
void cleanupGraphics(Graphics *gfx) {
    SDL_DestroyRenderer(gfx->renderer);
    SDL_DestroyWindow(gfx->window);
    SDL_Quit();
}

// Dessine le jeu dans la fen�tre
void renderGame(Graphics *gfx, GameState *game) {
    // Nettoyage de l'�cran (fond noir)
    SDL_SetRenderDrawColor(gfx->renderer, 0, 0, 0, 255);
    SDL_RenderClear(gfx->renderer);

    // Dessiner les murs en blanc
    SDL_SetRenderDrawColor(gfx->renderer, 255, 255, 255, 255);
    for (int i = 0; i < Largeur_Map; i++) {
        for (int j = 0; j < MAP_HEIGHT; j++) {
            if (Collision_Mur(i, j)) {
                SDL_Rect wall = { i * CELL_SIZE, j * CELL_SIZE, CELL_SIZE, CELL_SIZE };
                SDL_RenderFillRect(gfx->renderer, &wall);
            }
        }
    }

    // Dessiner le fruit en rouge
    SDL_SetRenderDrawColor(gfx->renderer, 255, 0, 0, 255);
    SDL_Rect fruit = { game->fruit.x * CELL_SIZE, game->fruit.y * CELL_SIZE, CELL_SIZE, CELL_SIZE };
    SDL_RenderFillRect(gfx->renderer, &fruit);

    // Dessiner le serpent en vert
    SDL_SetRenderDrawColor(gfx->renderer, 0, 255, 0, 255);
    for (int i = game->snake.queue; i != game->snake.tete; i = (i + 1) % MAX_LENGTH) {
        SDL_Rect bodyPart = { game->snake.body[i].x * CELL_SIZE, game->snake.body[i].y * CELL_SIZE, CELL_SIZE, CELL_SIZE };
        SDL_RenderFillRect(gfx->renderer, &bodyPart);
    }

    // Dessiner la t�te du serpent en bleu
    SDL_SetRenderDrawColor(gfx->renderer, 0, 0, 255, 255);
    SDL_Rect head = { game->snake.body[game->snake.tete].x * CELL_SIZE, game->snake.body[game->snake.tete].y * CELL_SIZE, CELL_SIZE, CELL_SIZE };
    SDL_RenderFillRect(gfx->renderer, &head);

    // Mettre � jour l'affichage
    SDL_RenderPresent(gfx->renderer);
}

