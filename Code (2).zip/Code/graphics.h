#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <SDL2/SDL.h>
#include "game.h"

// D�finition de la taille des cellules (chaque case de la grille)
#define CELL_SIZE 20

// Structure pour stocker les �l�ments graphiques
typedef struct {
    SDL_Window *window;
    SDL_Renderer *renderer;
} Graphics;

// Initialisation de la fen�tre et du rendu
bool initGraphics(Graphics *gfx);

// Nettoyage des ressources SDL
void cleanupGraphics(Graphics *gfx);

// Affichage du jeu
void renderGame(Graphics *gfx, GameState *game);

#endif // GRAPHICS_H

