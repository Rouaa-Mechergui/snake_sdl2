
#ifndef SNAKE_H
#define SNAKE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_LENGTH 100  // Longueur max du serpent

// Structure pour repr�senter une position sur la grille
typedef struct {
    int x;
    int y;
} Position;

// Structure du serpent (file circulaire)
typedef struct {
    Position body[MAX_LENGTH];  // Tableau des positions
    int tete;  // Indice de la t�te
    int queue;  // Indice de la queue
    int taille;  // Taille actuelle
} Snake;

// Fonctions du module Snake
void initialiser_serpent(Snake *snake, int X0, int Y0);
bool deplacer_serpent(Snake *snake, int nv_X, int nv_Y, bool grow);
bool detection_collision(Snake *snake, int x, int y);
void afficher_serpent(Snake *snake);

#endif // SNAKE_H
