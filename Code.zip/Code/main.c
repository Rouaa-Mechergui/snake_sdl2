#include <stdio.h>
#include <stdbool.h>
#include <SDL2/SDL.h>

#include "game.h"
#include "graphics.h"

#define FRAME_DELAY 200  // D�lai entre les frames (ms)

int main(int argc, char *argv[]) {
    GameState game;
    Graphics gfx;

    // Initialisation SDL et fen�tre
    if (!initGraphics(&gfx)) {
        printf("Erreur initialisation SDL.\n");
        return 1;
    }

    // Initialisation du jeu avec le serpent au centre
    initialiser_jeu(&game, Largeur_Map / 2, Hauteur_Map / 2, false);

    bool running = true;
    SDL_Event event;

    // Boucle de jeu principale
    while (running && !game.game_over) {
        // Gestion des �v�nements clavier
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.sym) {
                    case SDLK_UP:    changer_direction(&game, UP); break;
                    case SDLK_DOWN:  changer_direction(&game, DOWN); break;
                    case SDLK_LEFT:  changer_direction(&game, LEFT); break;
                    case SDLK_RIGHT: changer_direction(&game, RIGHT); break;
                    case SDLK_ESCAPE: running = false; break;
                }
            }
        }

        // Mettre � jour le jeu
        update_jeu(&game);

        // Afficher le jeu
        renderGame(&gfx, &game);

        SDL_Delay(FRAME_DELAY); // D�lai pour contr�ler la vitesse
    }

    // Afficher le score � la fin
    printf("\n--- GAME OVER ---\n");
    printf("Score : %d\n", game.score);

    // Nettoyage SDL
    cleanupGraphics(&gfx);
    SDL_Quit();

    return 0;
}

